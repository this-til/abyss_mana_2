package mcp.mobius.waila.api;

public enum TagLocation {
    STACK, // Block only
    OVERRIDE, // Entity only
    HEAD,
    BODY,
    TAIL,
    DATA
}
