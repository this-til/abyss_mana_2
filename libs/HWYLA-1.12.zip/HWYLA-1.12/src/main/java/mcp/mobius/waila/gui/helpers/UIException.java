package mcp.mobius.waila.gui.helpers;

public class UIException extends RuntimeException {
    public UIException(String message) {
        super(message);
    }
}
