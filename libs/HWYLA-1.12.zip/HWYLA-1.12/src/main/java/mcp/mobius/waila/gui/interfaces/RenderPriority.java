package mcp.mobius.waila.gui.interfaces;

public enum RenderPriority {
    LOW,
    MEDIUM,
    HIGH;
}
