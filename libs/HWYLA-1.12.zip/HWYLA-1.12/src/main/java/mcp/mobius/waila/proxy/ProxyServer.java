package mcp.mobius.waila.proxy;

public class ProxyServer extends ProxyCommon {

}
