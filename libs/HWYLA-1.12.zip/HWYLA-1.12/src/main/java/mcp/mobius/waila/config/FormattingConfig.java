package mcp.mobius.waila.config;

public class FormattingConfig {

    public static String modNameFormat = "\u00A79\u00A7o%s";
    public static String blockFormat = "\u00a7f%s";
    public static String fluidFormat = "\u00a7f%s";
    public static String entityFormat = "\u00a7f%s";
    public static String metaFormat = "\u00a77[%s@%d]";
}
