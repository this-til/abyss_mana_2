package mcp.mobius.waila.cbcore;

public enum Layout {
    HEADER, BODY, FOOTER
}
