package mezz.jei.suffixtree;

import it.unimi.dsi.fastutil.ints.IntSet;

public interface ISearchTree {
	IntSet search(String word);
}
