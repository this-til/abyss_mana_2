package mezz.jei.gui.recipes;

public interface IRecipeLogicStateListener {
	void onStateChange();
}
