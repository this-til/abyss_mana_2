package mezz.jei.gui.overlay;

public enum GridAlignment {
	LEFT, RIGHT
}
